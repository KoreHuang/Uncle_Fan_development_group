
public class samsung extends usb{
	public void read(){
		System.out.println("I'm samsung disk ...  read");
	}
	public void write(){
		System.out.println("I'm samsung disk ...  write");
	}
	
}
