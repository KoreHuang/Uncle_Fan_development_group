
public abstract class usb {
	public abstract void read();
	public abstract void write();
}
