
public class M3 implements Miaoji {
	public void open() {
		System.out.println("孙夫人断后...");
	}
}
