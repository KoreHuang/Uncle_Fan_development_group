
public abstract class animals {
	int age;
	public animals(int a) {
		// TODO Auto-generated constructor stub
		age=a;
	}
	public abstract void sound();
}
