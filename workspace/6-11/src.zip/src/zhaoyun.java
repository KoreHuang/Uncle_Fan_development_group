
public class zhaoyun {
	public static void main(String[] args) {
		M1 m1=new M1();
		M2 m2=new M2();
		M3 m3=new M3();
		
		JN j=new JN();
		
		j.open(m1);
		j.open(m2);
		j.open(m3);
	}
}
