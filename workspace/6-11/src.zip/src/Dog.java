
public class Dog extends animals{
	public Dog(int age) {
		super(age);
		// TODO Auto-generated constructor stub
	}
	@Override
	public void sound() {
		// TODO Auto-generated method stub
		System.out.println("wang wang wang...");
	}
	
}
