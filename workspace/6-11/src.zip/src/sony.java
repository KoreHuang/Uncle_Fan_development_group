
public class sony extends usb{

		public void read(){
			System.out.println("I'm sony disk ...  read");
		}
		public void write(){
			System.out.println("I'm sony disk ...  write");
		}
		
	

}
