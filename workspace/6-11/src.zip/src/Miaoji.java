
public interface Miaoji {
	public void open();
}
