
public  class M1 implements Miaoji {
	public void open() {
		System.out.println("找乔国老帮忙...");
	}
}
