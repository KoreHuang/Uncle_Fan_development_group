
public class JN {
	public void open(Miaoji m) {
		m.open();
	}
}
