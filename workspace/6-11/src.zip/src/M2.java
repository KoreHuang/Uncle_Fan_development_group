
public class M2 implements Miaoji{
	public void open() {
		System.out.println("让孙国太压制孙权....");
	}
}
